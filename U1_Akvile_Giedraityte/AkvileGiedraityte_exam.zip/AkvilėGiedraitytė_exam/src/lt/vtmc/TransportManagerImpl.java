package lt.vtmc;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import lt.vtmc.exam.Bus;
import lt.vtmc.exam.Passenger;
import lt.vtmc.exam.PassengerPredicate;
import lt.vtmc.exam.SeatIsOccupiedException;
import lt.vtmc.exam.TransportManager;

public class TransportManagerImpl implements TransportManager {

	private Map<String, Bus> buses = new HashMap<>();

	private Map<String, List<Passenger>> busPassengersMap = new HashMap<String, List<Passenger>>();

	private Map<String, List<Integer>> busSeatsTaken = new HashMap<String, List<Integer>>();

	@Override
	public Bus createBus(String id, int seats) {
		if (seats <= 0) {
			throw new IllegalArgumentException("Bus mus have more than zero seats. Provided param was: " + seats);
		}
		Bus bus = buses.get(id);

		if (bus == null) {
			bus = new Bus(id, seats);
			busPassengersMap.put(id, new ArrayList<Passenger>());
			busSeatsTaken.put(id, new ArrayList<Integer>());
		} else {
			throw new IllegalArgumentException("Bus with id " + id + " already exists");
		}

		return bus;
	}

	@Override
	public Passenger createPassenger(String name, String surname, int age) {
		if (name == null || name.trim().isEmpty() || surname == null || surname.isEmpty() || age <= 0) {
			new IllegalArgumentException("New passenger must have a name, surname and an age over 0");
		}
		return new Passenger(name, surname, age);
	}

	@Override
	public List<Passenger> findPassengersBy(String busId, PassengerPredicate predicate) {
		List<Passenger> busPassengers = busPassengersMap.get(busId);

		if (busPassengers == null) {
			throw new IllegalArgumentException("Bus with id " + busId + " does not exist");
		}

		return busPassengers.stream().filter(p -> predicate.test(p)).collect(Collectors.toList());
	}

	@Override
	public double getAveragePassengerAge(String arg0) {
		return busPassengersMap.values().stream().flatMap(e -> e.stream())
				.collect(Collectors.averagingDouble(p -> p.getAge()));
	}

	@Override
	public Bus getBusById(String id) {
		return buses.get(id);
	}

	@Override
	public List<Bus> getCreatedBuses() {
		return buses.values().stream().collect(Collectors.toList());
	}

	@Override
	public Passenger getOldestPassenger(String arg0) {

		return busPassengersMap.values().stream().flatMap(e -> e.stream())
				.collect(Collectors.maxBy((p1, p2) -> p2.getAge() - p1.getAge())).orElse(null);
	}

	@Override
	public Collection<Passenger> getOrderedPassengers(String busId) {
		return getPassengers(busId).stream()
				.sorted(Comparator.comparing(Passenger::getSurname).thenComparing(Passenger::getName))
				.collect(Collectors.toList());
	}

	@Override
	public List<Passenger> getPassengers(String busId) {
		return findPassengersBy(busId, p -> true);
	}

	@Override
	public void registerPassenger(Bus bus, int seatNo, Passenger passenger) throws SeatIsOccupiedException {
		String busId = bus.getId();

		if (bus.getSeats() < seatNo) {
			throw new IllegalArgumentException("Bus with id " + busId + " does not have seat with number " + seatNo
					+ ". Max seat number is " + bus.getSeats());
		}

		List<Integer> busSeats = busSeatsTaken.get(busId);

		if (busSeats.contains(seatNo)) {
			throw new SeatIsOccupiedException();
		} else {
			busSeats.add(seatNo);
		}
	}

}